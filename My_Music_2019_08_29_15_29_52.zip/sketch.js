function preload() {
  soundFormats('mp3', 'ogg','wav');
  AlphysTakesAction = loadSound('Alphys takes action.mp3');

}

function setup() {
  AlphysTakesAction.setVolume(5.1);
  button = createButton('AlphysTakesAction');
  button.mousePressed(playSong);
}

function playSong() {
  AlphysTakesAction.play(); 
  
}